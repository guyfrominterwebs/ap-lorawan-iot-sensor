1. IDE - Arduino 1.0.6;
2. API for hardware:
(1) LSensorHub.h - Xadow Basic Sensors
(2) LLedMatrix.h - Xadow LED 5x7
(3) LGPS.h - Xadow GPS v2
(4) LNFC.h - Xadow NFC v2
(5) LWs2812.h - Xadow Duino